


    $(function(){
        $(".one").click(function(){
                $(".two").toggle(1000);
        });
    })