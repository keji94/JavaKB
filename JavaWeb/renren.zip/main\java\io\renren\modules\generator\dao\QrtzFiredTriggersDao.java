package io.renren.modules.generator.dao;

import io.renren.modules.generator.entity.QrtzFiredTriggersEntity;
import org.apache.ibatis.annotations.Mapper;

/**
 * 
 * 
 * @author chenshun
 * @email sunlightcs@gmail.com
 * @date 2017-10-20 10:54:53
 */
@Mapper
public interface QrtzFiredTriggersDao extends BaseDao<QrtzFiredTriggersEntity> {
	
}
